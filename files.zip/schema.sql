create table kv (id text primary key, coll text, data jsonb, ts bigint);
create index on kv (ts);
alter table kv enable row level security;
create policy "all" on kv for all using (true) with check (true);
